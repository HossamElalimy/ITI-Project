document.addEventListener('DOMContentLoaded', () => {
  /* --- 1) Reveal-on-scroll for anything with [data-reveal] --- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) e.target.classList.add('in');
    });
  }, { threshold: 0.15 });

  document.querySelectorAll('[data-reveal]').forEach(el => io.observe(el));

  /* --- 2) Equalize feature heights by row (so grid aligns nicely) --- */
  function equalize() {
    const items = Array.from(document.querySelectorAll('.feature'));
    // reset first
    items.forEach(i => i.style.minHeight = '');
    // group by row (approximate using document top)
    const rows = {};
    items.forEach(i => {
      const top = Math.round(i.getBoundingClientRect().top + window.scrollY);
      (rows[top] ||= []).push(i);
    });
    Object.values(rows).forEach(group => {
      const h = Math.max(...group.map(g => g.offsetHeight));
      group.forEach(g => g.style.minHeight = h + 'px');
    });
  }
  equalize();
  window.addEventListener('resize', equalize);

  /* --- 3) Hover/focus states for accessibility --- */
  document.querySelectorAll('.feature').forEach(card => {
    card.tabIndex = 0;
    const on = () => card.classList.add('active');
    const off = () => card.classList.remove('active');
    card.addEventListener('mouseenter', on);
    card.addEventListener('mouseleave', off);
    card.addEventListener('focus', on);
    card.addEventListener('blur', off);
  });

  /* --- 4) Ripple on the “All Rules” button --- */
  const btn = document.querySelector('.btn-outline');
  if (btn) {
    btn.addEventListener('click', (e) => {
      const r = document.createElement('span');
      r.className = 'ripple';
      const rect = btn.getBoundingClientRect();
      r.style.left = (e.clientX - rect.left) + 'px';
      r.style.top  = (e.clientY - rect.top) + 'px';
      btn.appendChild(r);
      setTimeout(() => r.remove(), 650);
    });
  }
});
